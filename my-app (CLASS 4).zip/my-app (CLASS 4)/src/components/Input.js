import React, { useState } from 'react';


function Input() {
    const [text, setText] = useState("")
    const onChangeHandler = (event) => {
        console.log(event.target.value)
        setText(event.target.value)
    }


    return (
        <div>
            <h1> {text} </h1>
            
        </div>
    );
}


export default Input;